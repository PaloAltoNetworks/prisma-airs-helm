---
Title: AI Runtime Security deployment templates for On-Prem


### Go to `helm`

Please execute the command:

    ```bash

    helm install `<RELEASE_NAME: the name you want>`

    ```

