# Prisma AIRS AI Runtime Helm Deployment

This is a repository for YAMLs to deploy Prisma AIRS AI Runtime: Network intercept for on-prem installations.
Please read the `README.md` in the `helm` folder for instructions to apply the Helm chart.

## Documentation

[Prisma AIRS AI Runtime Security](https://docs.paloaltonetworks.com/ai-runtime-security)
